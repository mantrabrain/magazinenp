<?php

include_once 'about/class-magazinenp-about.php';
include_once 'customizer/section-pro.php';

