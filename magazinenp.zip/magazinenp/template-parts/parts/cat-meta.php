<div class="entry-meta category-meta">
    <?php magazinenp_category_list(); ?>
</div>
