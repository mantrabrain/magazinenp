<?php
if (has_header_video() || has_header_image()) {
	the_custom_header_markup();
}
